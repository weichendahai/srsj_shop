package com.srsj.service;

import com.srsj.common.service.IBaseService;
import com.srsj.model.SysRole;

/**
 * Created by weichen on 2017/5/25.
 */
//
//public interface ISysRoleService extends IBaseService<SysRole> {
//
////    int deleteByPrimaryKey(Long id);
////
////    int insert(SysRole record);
////
////    int insertSelective(SysRole record);
////
////    SysRole selectByPrimaryKey(Long id);
////
////    int updateByPrimaryKeySelective(SysRole record);
////
////    int updateByPrimaryKey(SysRole record);
////
////    List<SysRole> selectAllList();
//}

//public interface ISysRoleService  {
//    List<SysRole> queryAll ();
//}

public interface ISysRoleService extends IBaseService<SysRole> {

}