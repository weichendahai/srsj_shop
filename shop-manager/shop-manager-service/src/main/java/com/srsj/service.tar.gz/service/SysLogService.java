/*
 * Powered By [rapid-framework]
 * Web Site: http://www.rapid-framework.org.cn
 * Google Code: http://code.google.com/p/rapid-framework/
 * Since 2008 - 2017
 */


package com.srsj.service;

import com.srsj.common.service.IBaseService;
import com.srsj.model.SysLog;

/**
 * Created by weichen on 2017/5/25.
 * @version 1.0
 * @author
 */

public interface SysLogService extends IBaseService<SysLog> {

}

