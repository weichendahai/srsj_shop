package com.srsj.service;

import com.srsj.common.service.IBaseService;
import com.srsj.model.SysUser;

/**
 * Created by weichen on 2017/5/25.
 */

public interface ISysUserService extends IBaseService<SysUser> {

}

//public interface ISysUserService  {
//    List<SysUser> queryAll ();
//}