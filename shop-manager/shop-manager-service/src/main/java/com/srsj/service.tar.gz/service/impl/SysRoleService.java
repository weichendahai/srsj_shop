package com.srsj.service.impl;

import com.srsj.common.service.impl.BaseServiceImpl;
import com.srsj.dao.SysRoleDao;
import com.srsj.model.SysRole;
import com.srsj.service.ISysRoleService;
import org.springframework.stereotype.Service;

/**
 * Created by weichen on 2017/5/25.
 */

//@Service
//public class SysRoleService implements ISysRoleService {
//    @Autowired
//    protected  SysRoleMapper sysRoleMapper;
//
//    public List<SysRole> queryAll () {
//        return sysRoleMapper.queryAll();
//    }
//}

//public class UserWalletService extends BaseServiceImpl<UserWallet> {
//@Service
//public class SysRoleService extends BaseServiceImpl<SysRole> {
//

@Service
public class SysRoleService extends BaseServiceImpl<SysRoleDao,SysRole> implements ISysRoleService {

}



